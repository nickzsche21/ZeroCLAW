"""
ZeroClaw Patcher — automatically updates OpenClaw config to use local AirLLM
Supports both JSON (config.json) and JS (config.js) formats.
"""

import os
import re
import json
import glob
import shutil
from pathlib import Path


# ── Known OpenClaw config paths ────────────────────────────────────────────────
SEARCH_PATHS = [
    "~/.openclaw/config.json",
    "~/.openclaw/config.js",
    "~/openclaw/config.json",
    "~/openclaw/config.js",
    "~/.config/openclaw/config.json",
    "~/.config/openclaw/config.js",
    "./config.json",
    "./config.js",
]


def find_openclaw_config() -> Path | None:
    """Search common locations for OpenClaw config."""
    for pattern in SEARCH_PATHS:
        expanded = Path(pattern).expanduser()
        if expanded.exists():
            return expanded

    # Also try glob for any openclaw folder
    for pattern in ["~/**/openclaw/config.*", "~/**/.openclaw/config.*"]:
        matches = glob.glob(str(Path(pattern).expanduser()), recursive=True)
        if matches:
            return Path(matches[0])

    return None


def backup_config(config_path: Path) -> Path:
    """Create a backup before patching."""
    backup = config_path.with_suffix(config_path.suffix + ".zeroclaw-backup")
    shutil.copy2(config_path, backup)
    print(f"[ZeroClaw] 💾 Backup saved to: {backup}")
    return backup


def patch_json_config(config_path: Path, host: str, port: int, model: str) -> bool:
    """Patch a JSON config file."""
    with open(config_path, "r") as f:
        try:
            config = json.load(f)
        except json.JSONDecodeError as e:
            print(f"[ZeroClaw] ❌ Failed to parse JSON: {e}")
            return False

    # Navigate to agent config
    if "agent" not in config:
        config["agent"] = {}

    config["agent"]["provider"] = "opencode"
    config["agent"]["opencode"] = {
        "model": f"openai/{model}",
        "hostname": host,
        "port": port,
    }

    backup_config(config_path)
    with open(config_path, "w") as f:
        json.dump(config, f, indent=2)

    print(f"[ZeroClaw] ✅ JSON config patched: {config_path}")
    return True


def patch_js_config(config_path: Path, host: str, port: int, model: str) -> bool:
    """Patch a JS config file by finding and replacing provider/model settings."""
    with open(config_path, "r") as f:
        content = f.read()

    backup_config(config_path)

    # ZeroClaw injection block
    injection = f"""
  // ── ZeroClaw: Local LLM via AirLLM (zero API cost) ──────────────────────
  agent: {{
    provider: 'opencode',
    opencode: {{
      model: 'openai/{model}',
      hostname: '{host}',
      port: {port},
    }},
  }},
  // ─────────────────────────────────────────────────────────────────────────"""

    # If there's already an agent block, replace it
    agent_pattern = re.compile(
        r"agent\s*:\s*\{[^}]*(?:\{[^}]*\}[^}]*)?\}",
        re.DOTALL
    )

    if agent_pattern.search(content):
        content = agent_pattern.sub(injection.strip(), content, count=1)
        print("[ZeroClaw] ✅ Replaced existing agent config block")
    else:
        # Insert before the last closing brace/bracket of the export
        content = re.sub(
            r"(module\.exports\s*=\s*\{)(.*?)(\};\s*$)",
            lambda m: m.group(1) + m.group(2) + "\n" + injection + "\n" + m.group(3),
            content,
            flags=re.DOTALL
        )
        print("[ZeroClaw] ✅ Injected agent config block")

    with open(config_path, "w") as f:
        f.write(content)

    print(f"[ZeroClaw] ✅ JS config patched: {config_path}")
    return True


def patch_openclaw(
    host: str = "127.0.0.1",
    port: int = 4096,
    model: str = "local-model",
    config_path: str | None = None
) -> bool:
    """
    Main entry point. Finds and patches OpenClaw config to use ZeroClaw.
    """
    if config_path:
        path = Path(config_path).expanduser()
    else:
        path = find_openclaw_config()

    if path is None:
        print("""
[ZeroClaw] ⚠️  Could not find OpenClaw config automatically.

Please run:
  zeroclaw patch --config /path/to/your/openclaw/config.json

Or manually add to your OpenClaw config:

  agent: {
    provider: 'opencode',
    opencode: {
      model: 'openai/local-model',
      hostname: '127.0.0.1',
      port: 4096,
    },
  }
""")
        return False

    print(f"[ZeroClaw] Found config: {path}")

    if path.suffix == ".json":
        return patch_json_config(path, host, port, model)
    elif path.suffix == ".js":
        return patch_js_config(path, host, port, model)
    else:
        print(f"[ZeroClaw] ❌ Unknown config format: {path.suffix}")
        return False


def restore_backup(config_path: str | None = None) -> bool:
    """Restore the original config from backup."""
    if config_path:
        path = Path(config_path).expanduser()
    else:
        path = find_openclaw_config()

    if path is None:
        print("[ZeroClaw] ❌ Could not find config to restore.")
        return False

    for suffix in [".json.zeroclaw-backup", ".js.zeroclaw-backup"]:
        backup = path.parent / (path.name + ".zeroclaw-backup")
        if backup.exists():
            shutil.copy2(backup, path)
            print(f"[ZeroClaw] ✅ Restored backup from: {backup}")
            return True

    print("[ZeroClaw] ❌ No backup found.")
    return False


if __name__ == "__main__":
    patch_openclaw()
