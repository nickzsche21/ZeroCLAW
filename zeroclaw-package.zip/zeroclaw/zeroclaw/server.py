"""
ZeroClaw Server — AirLLM wrapped as an OpenAI-compatible API
Runs 70B models on a single 4GB GPU. Zero API cost.
"""

import os
import time
import uuid
import json
import argparse
import threading
from typing import Optional, List
from pathlib import Path

# ── FastAPI / Uvicorn ──────────────────────────────────────────────────────────
try:
    from fastapi import FastAPI, HTTPException
    from fastapi.responses import StreamingResponse, JSONResponse
    from pydantic import BaseModel
    import uvicorn
except ImportError:
    print("[ZeroClaw] Installing FastAPI...")
    os.system("pip install fastapi uvicorn pydantic --break-system-packages -q")
    from fastapi import FastAPI, HTTPException
    from fastapi.responses import StreamingResponse, JSONResponse
    from pydantic import BaseModel
    import uvicorn

# ── AirLLM ─────────────────────────────────────────────────────────────────────
try:
    from airllm import AutoModel
except ImportError:
    print("[ZeroClaw] Installing AirLLM...")
    os.system("pip install airllm --break-system-packages -q")
    from airllm import AutoModel

# ── Config ─────────────────────────────────────────────────────────────────────
DEFAULT_MODEL = os.environ.get("ZEROCLAW_MODEL", "mistralai/Mistral-7B-Instruct-v0.2")
DEFAULT_PORT  = int(os.environ.get("ZEROCLAW_PORT", "4096"))
MAX_NEW_TOKENS = int(os.environ.get("ZEROCLAW_MAX_TOKENS", "512"))

app = FastAPI(title="ZeroClaw — Local LLM API", version="1.0.0")

# ── Global model state ─────────────────────────────────────────────────────────
_model      = None
_model_name = DEFAULT_MODEL
_model_lock = threading.Lock()


def load_model(model_id: str):
    global _model, _model_name
    print(f"\n[ZeroClaw] Loading model: {model_id}")
    print("[ZeroClaw] This downloads the model on first run (~4–14 GB). Subsequent starts are instant.\n")
    with _model_lock:
        _model = AutoModel.from_pretrained(model_id)
        _model_name = model_id
    print(f"[ZeroClaw] ✅ Model ready: {model_id}\n")


# ── Request / Response schemas (OpenAI-compatible) ─────────────────────────────
class ChatMessage(BaseModel):
    role: str
    content: str

class ChatCompletionRequest(BaseModel):
    model: Optional[str] = None
    messages: List[ChatMessage]
    max_tokens: Optional[int] = None
    temperature: Optional[float] = 0.7
    stream: Optional[bool] = False

class CompletionRequest(BaseModel):
    model: Optional[str] = None
    prompt: str
    max_tokens: Optional[int] = None
    temperature: Optional[float] = 0.7
    stream: Optional[bool] = False


# ── Helpers ────────────────────────────────────────────────────────────────────
def messages_to_prompt(messages: List[ChatMessage]) -> str:
    """Convert chat messages to a single prompt string."""
    prompt = ""
    for m in messages:
        if m.role == "system":
            prompt += f"<s>[INST] <<SYS>>\n{m.content}\n<</SYS>>\n\n"
        elif m.role == "user":
            prompt += f"{m.content} [/INST] "
        elif m.role == "assistant":
            prompt += f"{m.content} </s><s>[INST] "
    return prompt.strip()


def run_inference(prompt: str, max_new_tokens: int) -> str:
    global _model
    if _model is None:
        raise HTTPException(status_code=503, detail="Model not loaded yet. Try again in a moment.")

    tokens = _model.tokenizer(
        [prompt],
        return_tensors="pt",
        padding=True,
        truncation=True,
        max_length=2048,
    )

    with _model_lock:
        output = _model.generate(
            **tokens,
            max_new_tokens=max_new_tokens,
            use_cache=True,
            return_dict_in_generate=False,
        )

    # Decode only the NEW tokens (skip input prompt tokens)
    input_len = tokens["input_ids"].shape[1]
    new_tokens = output[0][input_len:]
    return _model.tokenizer.decode(new_tokens, skip_special_tokens=True).strip()


# ── Routes ─────────────────────────────────────────────────────────────────────
@app.get("/")
def root():
    return {
        "status": "ok",
        "service": "ZeroClaw Local LLM",
        "model": _model_name,
        "ready": _model is not None,
    }

@app.get("/v1/models")
def list_models():
    return {
        "object": "list",
        "data": [{
            "id": _model_name,
            "object": "model",
            "created": int(time.time()),
            "owned_by": "zeroclaw",
        }]
    }

@app.post("/v1/chat/completions")
def chat_completions(req: ChatCompletionRequest):
    prompt = messages_to_prompt(req.messages)
    max_t  = req.max_tokens or MAX_NEW_TOKENS
    text   = run_inference(prompt, max_t)

    response_id = f"chatcmpl-{uuid.uuid4().hex[:12]}"
    return {
        "id": response_id,
        "object": "chat.completion",
        "created": int(time.time()),
        "model": _model_name,
        "choices": [{
            "index": 0,
            "message": {"role": "assistant", "content": text},
            "finish_reason": "stop",
        }],
        "usage": {
            "prompt_tokens": len(prompt.split()),
            "completion_tokens": len(text.split()),
            "total_tokens": len(prompt.split()) + len(text.split()),
        },
    }

@app.post("/v1/completions")
def completions(req: CompletionRequest):
    max_t = req.max_tokens or MAX_NEW_TOKENS
    text  = run_inference(req.prompt, max_t)

    return {
        "id": f"cmpl-{uuid.uuid4().hex[:12]}",
        "object": "text_completion",
        "created": int(time.time()),
        "model": _model_name,
        "choices": [{
            "text": text,
            "index": 0,
            "finish_reason": "stop",
        }],
    }

@app.get("/health")
def health():
    return {"status": "ok", "model_loaded": _model is not None}


# ── Entry point ─────────────────────────────────────────────────────────────────
def start_server(model: str = DEFAULT_MODEL, port: int = DEFAULT_PORT, host: str = "127.0.0.1"):
    # Load model in background so server starts responding immediately
    t = threading.Thread(target=load_model, args=(model,), daemon=True)
    t.start()

    print(f"""
╔══════════════════════════════════════════════════════╗
║           ZeroClaw — Local LLM Server                ║
║  Model  : {model:<41} ║
║  Port   : {port:<41} ║
║  OpenAI API at: http://{host}:{port}/v1           ║
╚══════════════════════════════════════════════════════╝
""")
    uvicorn.run(app, host=host, port=port, log_level="warning")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="ZeroClaw Local LLM Server")
    parser.add_argument("--model", default=DEFAULT_MODEL, help="HuggingFace model ID")
    parser.add_argument("--port",  default=DEFAULT_PORT,  type=int)
    parser.add_argument("--host",  default="127.0.0.1")
    args = parser.parse_args()
    start_server(args.model, args.port, args.host)
