"""
ZeroClaw CLI — run, patch, restore, status
"""

import os
import sys
import json
import time
import argparse
import subprocess

BANNER = r"""
 ███████╗███████╗██████╗  ██████╗  ██████╗██╗      █████╗ ██╗    ██╗
 ╚══███╔╝██╔════╝██╔══██╗██╔═══██╗██╔════╝██║     ██╔══██╗██║    ██║
   ███╔╝ █████╗  ██████╔╝██║   ██║██║     ██║     ███████║██║ █╗ ██║
  ███╔╝  ██╔══╝  ██╔══██╗██║   ██║██║     ██║     ██╔══██║██║███╗██║
 ███████╗███████╗██║  ██║╚██████╔╝╚██████╗███████╗██║  ██║╚███╔███╔╝
 ╚══════╝╚══════╝╚═╝  ╚═╝ ╚═════╝  ╚═════╝╚══════╝╚═╝  ╚═╝ ╚══╝╚══╝
 
 Run OpenClaw on ANY GPU with ZERO API cost — powered by AirLLM
 ──────────────────────────────────────────────────────────────
"""

MODELS = {
    "7b":  "mistralai/Mistral-7B-Instruct-v0.2",   # Best for 4GB GPU
    "8b":  "meta-llama/Meta-Llama-3-8B-Instruct",   # Best for 6GB GPU
    "13b": "meta-llama/Llama-2-13B-chat-hf",         # Best for 8GB GPU
    "70b": "meta-llama/Llama-2-70B-chat-hf",         # 4GB GPU, slower
}

DEFAULT_MODEL = MODELS["7b"]
DEFAULT_PORT  = 4096
DEFAULT_HOST  = "127.0.0.1"


def cmd_start(args):
    """Start the ZeroClaw local LLM server."""
    from zeroclaw.server import start_server

    model = MODELS.get(args.model, args.model) if hasattr(args, 'model') and args.model else DEFAULT_MODEL
    port  = args.port if hasattr(args, 'port') and args.port else DEFAULT_PORT
    host  = args.host if hasattr(args, 'host') and args.host else DEFAULT_HOST

    print(BANNER)
    print(f"  Model : {model}")
    print(f"  Port  : {port}")
    print(f"  URL   : http://{host}:{port}/v1\n")

    start_server(model=model, port=port, host=host)


def cmd_patch(args):
    """Patch OpenClaw config to use ZeroClaw."""
    from zeroclaw.patch import patch_openclaw

    model = MODELS.get(args.model, args.model) if hasattr(args, 'model') and args.model else "local-model"
    port  = args.port if hasattr(args, 'port') and args.port else DEFAULT_PORT
    host  = args.host if hasattr(args, 'host') and args.host else DEFAULT_HOST
    cfg   = args.config if hasattr(args, 'config') and args.config else None

    print(BANNER)
    success = patch_openclaw(host=host, port=port, model=model, config_path=cfg)
    if success:
        print("\n[ZeroClaw] 🎉 Done! Now start ZeroClaw:")
        print("           zeroclaw start\n")
        print("[ZeroClaw] Then restart OpenClaw:")
        print("           openclaw restart  (or kill and re-run openclaw)\n")
    else:
        sys.exit(1)


def cmd_restore(args):
    """Restore original OpenClaw config from backup."""
    from zeroclaw.patch import restore_backup
    cfg = args.config if hasattr(args, 'config') and args.config else None
    restore_backup(cfg)


def cmd_status(args):
    """Check if ZeroClaw server is running."""
    try:
        import urllib.request
        port = args.port if hasattr(args, 'port') and args.port else DEFAULT_PORT
        url  = f"http://127.0.0.1:{port}/health"
        with urllib.request.urlopen(url, timeout=3) as resp:
            data = json.loads(resp.read())
            if data.get("model_loaded"):
                print(f"[ZeroClaw] ✅ Server running on port {port} — model loaded and ready!")
            else:
                print(f"[ZeroClaw] ⏳ Server running on port {port} — model still loading...")
    except Exception:
        port = args.port if hasattr(args, 'port') and args.port else DEFAULT_PORT
        print(f"[ZeroClaw] ❌ Server not running on port {port}")
        print("           Start it with: zeroclaw start")


def cmd_install(args):
    """Full automated setup: install deps, patch config, done."""
    print(BANNER)
    print("[ZeroClaw] 🚀 Running full automated setup...\n")

    # 1. Install Python deps
    print("[ZeroClaw] Installing dependencies...")
    os.system("pip install airllm fastapi uvicorn pydantic --break-system-packages -q")
    print("[ZeroClaw] ✅ Dependencies installed\n")

    # 2. Patch OpenClaw config
    print("[ZeroClaw] Patching OpenClaw config...")
    from zeroclaw.patch import patch_openclaw
    model = MODELS.get(args.model, args.model) if hasattr(args, 'model') and args.model else "local-model"
    port  = args.port if hasattr(args, 'port') and args.port else DEFAULT_PORT
    cfg   = args.config if hasattr(args, 'config') and args.config else None
    patch_openclaw(host=DEFAULT_HOST, port=port, model=model, config_path=cfg)

    print("""
[ZeroClaw] ✅ Setup complete!

  NEXT STEPS:
  ──────────────────────────────────────────────
  1. Start ZeroClaw (in one terminal):
       zeroclaw start

  2. Restart OpenClaw (in another terminal):
       openclaw restart

  3. Message your OpenClaw on WhatsApp/Telegram
     — it now runs locally with zero API cost!
  ──────────────────────────────────────────────
""")


def main():
    parser = argparse.ArgumentParser(
        description="ZeroClaw — Run OpenClaw with zero API cost via AirLLM",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Commands:
  start     Start the local LLM server
  patch     Patch OpenClaw config to use ZeroClaw
  restore   Restore original OpenClaw config
  status    Check if server is running
  install   Full automated setup (install + patch)

Models (shorthand):
  7b   → mistralai/Mistral-7B-Instruct-v0.2  (4GB+ GPU, fastest)
  8b   → meta-llama/Meta-Llama-3-8B-Instruct (6GB+ GPU)
  13b  → meta-llama/Llama-2-13B-chat-hf      (8GB+ GPU)
  70b  → meta-llama/Llama-2-70B-chat-hf      (4GB GPU, very slow)
  Or pass any HuggingFace model ID directly.

Examples:
  zeroclaw install
  zeroclaw start --model 8b
  zeroclaw start --model mistralai/Mistral-7B-Instruct-v0.2 --port 4096
  zeroclaw patch --config ~/openclaw/config.json
  zeroclaw status
"""
    )

    sub = parser.add_subparsers(dest="command")

    # start
    p_start = sub.add_parser("start", help="Start the local LLM server")
    p_start.add_argument("--model",  default=None, help="Model shorthand (7b/8b/13b/70b) or HF model ID")
    p_start.add_argument("--port",   default=DEFAULT_PORT, type=int)
    p_start.add_argument("--host",   default=DEFAULT_HOST)

    # patch
    p_patch = sub.add_parser("patch", help="Patch OpenClaw config")
    p_patch.add_argument("--model",  default=None)
    p_patch.add_argument("--port",   default=DEFAULT_PORT, type=int)
    p_patch.add_argument("--host",   default=DEFAULT_HOST)
    p_patch.add_argument("--config", default=None, help="Path to OpenClaw config file")

    # restore
    p_restore = sub.add_parser("restore", help="Restore original OpenClaw config")
    p_restore.add_argument("--config", default=None)

    # status
    p_status = sub.add_parser("status", help="Check server status")
    p_status.add_argument("--port", default=DEFAULT_PORT, type=int)

    # install
    p_install = sub.add_parser("install", help="Full automated setup")
    p_install.add_argument("--model",  default=None)
    p_install.add_argument("--port",   default=DEFAULT_PORT, type=int)
    p_install.add_argument("--config", default=None)

    args = parser.parse_args()

    if args.command == "start":
        cmd_start(args)
    elif args.command == "patch":
        cmd_patch(args)
    elif args.command == "restore":
        cmd_restore(args)
    elif args.command == "status":
        cmd_status(args)
    elif args.command == "install":
        cmd_install(args)
    else:
        print(BANNER)
        parser.print_help()


if __name__ == "__main__":
    main()
