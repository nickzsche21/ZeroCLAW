"""ZeroClaw — Run OpenClaw with zero API cost via AirLLM."""

__version__ = "1.0.0"
__author__  = "ZeroClaw"

from zeroclaw.server import start_server
from zeroclaw.patch   import patch_openclaw, restore_backup
